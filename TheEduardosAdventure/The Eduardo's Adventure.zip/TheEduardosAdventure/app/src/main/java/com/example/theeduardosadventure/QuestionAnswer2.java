package com.example.theeduardosadventure;

public class QuestionAnswer2 {
    public static String question[] ={
            "Qual a raiz de 2?",
            "Quala raiz de 3",
            "Qual a raiz de 4",
            "Qual a raiz de 5"
    };

    public static String choices[][] = {
            {"2","1,4","33","40"},
            {"20","6","4","1,7"},
            {"2","87","22","6"},
            {"76","8","2,2","14"}
    };

    public static String correctAnswers[] = {
            "1,4",
            "1,7",
            "2",
            "2,2"
    };

}